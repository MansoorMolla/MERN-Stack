// callback, promises, async/await
// call, bind, apply
// callby value, call by refrence
// shallow copy, deep copy
// map, filter, reducer
// for, for-in, for-of, for-Each, while, do-while
// closure, currying
// Destucturing, spread, rest, default

