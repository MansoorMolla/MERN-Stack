function Contact() {
    return (
        <>
            <h1>Hi, Welcome to Contact Page!!!</h1>
        </>
    );
}

export default Contact;