function Home() {
    return (
        <>
            <h1>Hi, Welcome to Home Page!!!</h1>
        </>
    );
}

export default Home;