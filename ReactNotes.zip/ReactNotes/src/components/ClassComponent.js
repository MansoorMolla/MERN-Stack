import React from "react";

export class CC extends React.Component {
    render() {
        return (
            <h1>These is react class component</h1>
        )
    }
}

