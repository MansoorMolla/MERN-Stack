function FC() {
    return (
        <h1>These is react functional component</h1>
    )
}

export default FC;