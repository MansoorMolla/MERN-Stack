function ChildComponent(props) {
    return (
        <h1>{props.message}</h1>
    )
}


export default ChildComponent;